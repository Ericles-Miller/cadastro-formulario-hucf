function mascaraCpf(valor) {
  return valor.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g, "$1.$2.$3-$4");
}

function mascaraTelefone(valor) {
  return valor.replace(/(\d{2})(\d{5})(\d{4})/g, "($1) $2-$3");
}

function validar(cpf) {
  const wrongChars = [
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
    ".",
    ",",
    ":",
    ";",
  ];
  let valido = true;

  for (char of wrongChars) {
    if (
      cpf.includes(char) ||
      cpf.length < 11 ||
      cpf == "00000000000" ||
      cpf == "11111111111" ||
      cpf == "22222222222" ||
      cpf == "33333333333" ||
      cpf == "44444444444" ||
      cpf == "55555555555" ||
      cpf == "66666666666" ||
      cpf == "77777777777" ||
      cpf == "88888888888" ||
      cpf == "99999999999"
    )
      valido = false;
  }

  return valido;
}

function retirarFormatacao(campoTexto) {
  campoTexto.value = campoTexto.value.replace(/(\.|\/|\-)/g, "");
}

function formatarCampoCpf(campoTexto) {
  if (validar(campoTexto.value))
    campoTexto.value = mascaraCpf(campoTexto.value);
  else {
    alert("Favor digitar um CPF válido.");
    campoTexto.value = "";
    campoTexto.focus();
  }
}

function formatarCampoTelefone(campoTexto) {
  if (validar(campoTexto.value))
    campoTexto.value = mascaraTelefone(campoTexto.value);
  else {
    alert("Favor digitar um telefone válido.");
    campoTexto.value = "";
    campoTexto.focus();
  }
}
